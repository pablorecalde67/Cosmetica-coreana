-- ============================================================
-- CDE KBEAUTY — ESQUEMA DE BASE DE DATOS (Supabase / Postgres)
-- Ejecutar en el SQL Editor de tu proyecto Supabase
-- ============================================================

create extension if not exists "uuid-ossp";

-- ---------- MARCAS ----------
create table if not exists brands (
  id uuid primary key default uuid_generate_v4(),
  name text not null,
  slug text not null unique,
  description text,
  logo_url text,
  created_at timestamptz not null default now()
);

-- ---------- CATEGORIAS ----------
create table if not exists categories (
  id uuid primary key default uuid_generate_v4(),
  name text not null,
  slug text not null unique,
  icon text,
  sort_order int not null default 0
);

-- ---------- TIENDAS ----------
create table if not exists stores (
  id uuid primary key default uuid_generate_v4(),
  name text not null,
  slug text not null unique,
  address text,
  whatsapp text,
  instagram text,
  website text,
  lat numeric,
  lng numeric,
  updated_at timestamptz not null default now()
);

-- ---------- PRODUCTOS ----------
create table if not exists products (
  id uuid primary key default uuid_generate_v4(),
  name text not null,
  slug text not null unique,
  brand_id uuid references brands(id) on delete set null,
  category_id uuid references categories(id) on delete set null,
  tagline text,
  description text,
  benefits text,
  skin_type text,
  key_ingredients text,
  how_to_use text,
  image_url text,
  is_featured boolean not null default false,
  is_new boolean not null default false,
  popularity int not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists idx_products_brand on products(brand_id);
create index if not exists idx_products_category on products(category_id);

-- ---------- PRECIOS POR TIENDA (STOCK incluido) ----------
create table if not exists product_prices (
  id uuid primary key default uuid_generate_v4(),
  product_id uuid references products(id) on delete cascade,
  store_id uuid references stores(id) on delete cascade,
  price_usd numeric(10,2) not null,
  stock text not null default 'in' check (stock in ('in','low','out')),
  updated_at timestamptz not null default now(),
  unique(product_id, store_id)
);
create index if not exists idx_prices_product on product_prices(product_id);
create index if not exists idx_prices_store on product_prices(store_id);

-- ---------- HISTORIAL DE PRECIOS (para alertas futuras) ----------
create table if not exists price_history (
  id uuid primary key default uuid_generate_v4(),
  product_id uuid references products(id) on delete cascade,
  store_id uuid references stores(id) on delete cascade,
  price_usd numeric(10,2) not null,
  stock text not null,
  recorded_at timestamptz not null default now()
);

create or replace function log_price_history() returns trigger as $$
begin
  insert into price_history(product_id, store_id, price_usd, stock)
  values (new.product_id, new.store_id, new.price_usd, new.stock);
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

drop trigger if exists trg_price_history on product_prices;
create trigger trg_price_history
before insert or update on product_prices
for each row execute function log_price_history();

-- ---------- RANKINGS (editables desde el admin) ----------
create table if not exists rankings (
  id uuid primary key default uuid_generate_v4(),
  slug text not null unique,
  label text not null,
  sort_order int not null default 0
);

create table if not exists ranking_items (
  id uuid primary key default uuid_generate_v4(),
  ranking_id uuid references rankings(id) on delete cascade,
  product_id uuid references products(id) on delete cascade,
  position int not null,
  unique(ranking_id, product_id)
);

-- ---------- PERFILES DE ADMIN ----------
create table if not exists profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  role text not null default 'admin'
);

-- ============================================================
-- ROW LEVEL SECURITY
-- Lectura pública para toda la vitrina. Escritura solo para
-- usuarios autenticados (los administradores que crees a mano
-- en Authentication > Users dentro de Supabase).
-- ============================================================
alter table brands enable row level security;
alter table categories enable row level security;
alter table stores enable row level security;
alter table products enable row level security;
alter table product_prices enable row level security;
alter table price_history enable row level security;
alter table rankings enable row level security;
alter table ranking_items enable row level security;
alter table profiles enable row level security;

create policy "public read brands" on brands for select using (true);
create policy "public read categories" on categories for select using (true);
create policy "public read stores" on stores for select using (true);
create policy "public read products" on products for select using (true);
create policy "public read product_prices" on product_prices for select using (true);
create policy "public read price_history" on price_history for select using (true);
create policy "public read rankings" on rankings for select using (true);
create policy "public read ranking_items" on ranking_items for select using (true);

create policy "admin write brands" on brands for all
  using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');
create policy "admin write categories" on categories for all
  using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');
create policy "admin write stores" on stores for all
  using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');
create policy "admin write products" on products for all
  using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');
create policy "admin write product_prices" on product_prices for all
  using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');
create policy "admin write rankings" on rankings for all
  using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');
create policy "admin write ranking_items" on ranking_items for all
  using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');

create policy "own profile read" on profiles for select using (auth.uid() = id);
create policy "own profile write" on profiles for update using (auth.uid() = id);
