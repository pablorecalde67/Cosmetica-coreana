import { signIn } from "@/lib/actions";

export default function LoginPage({ searchParams }: { searchParams: { error?: string } }) {
  return (
    <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", background: "var(--ink)" }}>
      <form action={signIn} style={{ background: "var(--paper)", padding: 36, borderRadius: 6, width: 360, maxWidth: "90vw" }}>
        <h1 style={{ fontSize: "1.4rem", marginBottom: 6 }}>CDE Kbeauty</h1>
        <p style={{ color: "var(--ink-soft)", fontSize: "0.86rem", marginBottom: 24 }}>Panel de administración</p>
        {searchParams.error && (
          <p style={{ color: "var(--blush)", fontSize: "0.82rem", marginBottom: 14 }}>
            Email o contraseña incorrectos.
          </p>
        )}
        <div className="form-field">
          <label>Email</label>
          <input type="email" name="email" required />
        </div>
        <div className="form-field">
          <label>Contraseña</label>
          <input type="password" name="password" required />
        </div>
        <button className="btn" type="submit" style={{ width: "100%", border: "none" }}>Ingresar</button>
        <p style={{ fontSize: "0.74rem", color: "var(--ink-soft)", marginTop: 18 }}>
          Los usuarios administradores se crean desde Supabase → Authentication → Users.
        </p>
      </form>
    </div>
  );
}
