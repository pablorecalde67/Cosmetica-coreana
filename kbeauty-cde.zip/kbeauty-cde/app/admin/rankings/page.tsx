import { createClient } from "@/lib/supabase/server";
import { addRankingItem, removeRankingItem } from "@/lib/actions";

export default async function AdminRankingsPage({ searchParams }: { searchParams: { r?: string } }) {
  const supabase = createClient();
  const { data: rankings } = await supabase.from("rankings").select("*").order("sort_order");
  const activeId = searchParams.r || rankings?.[0]?.id;

  const [{ data: products }, { data: items }] = await Promise.all([
    supabase.from("products").select("id, name").order("name"),
    activeId
      ? supabase.from("ranking_items").select("*, product:products(name)").eq("ranking_id", activeId).order("position")
      : Promise.resolve({ data: [] as any[] }),
  ]);

  return (
    <div>
      <h2 style={{ fontSize: "1.5rem", marginBottom: 20 }}>Rankings</h2>

      <div className="rank-tabs">
        {(rankings ?? []).map((r) => (
          <a key={r.id} href={`/admin/rankings?r=${r.id}`} className={r.id === activeId ? "active" : ""}>
            {r.label}
          </a>
        ))}
      </div>

      <form action={addRankingItem} style={{ display: "flex", gap: 10, alignItems: "flex-end", marginBottom: 28, flexWrap: "wrap" }}>
        <input type="hidden" name="ranking_id" value={activeId} />
        <div className="form-field" style={{ marginBottom: 0 }}>
          <label>Producto</label>
          <select name="product_id" required>
            {(products ?? []).map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
          </select>
        </div>
        <div className="form-field" style={{ marginBottom: 0, width: 100 }}>
          <label>Posición</label>
          <input name="position" type="number" min="1" defaultValue={(items?.length ?? 0) + 1} />
        </div>
        <button className="btn" style={{ border: "none" }}>Agregar al ranking</button>
      </form>

      <table className="admin-table">
        <thead><tr><th>#</th><th>Producto</th><th></th></tr></thead>
        <tbody>
          {(items ?? []).map((it: any) => (
            <tr key={it.id}>
              <td>{it.position}</td>
              <td>{it.product?.name}</td>
              <td>
                <form action={removeRankingItem}>
                  <input type="hidden" name="id" value={it.id} />
                  <button className="btn danger" style={{ padding: "4px 10px", fontSize: "0.78rem" }}>Quitar</button>
                </form>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
