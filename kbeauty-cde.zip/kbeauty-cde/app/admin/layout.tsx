import Link from "next/link";
import { signOut } from "@/lib/actions";

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="admin-shell">
      <aside className="admin-side">
        <div className="logo">CDE<span>Kbeauty</span></div>
        <nav>
          <Link href="/admin">Panel</Link>
          <Link href="/admin/productos">Productos</Link>
          <Link href="/admin/precios">Precios y stock</Link>
          <Link href="/admin/marcas">Marcas</Link>
          <Link href="/admin/tiendas">Tiendas</Link>
          <Link href="/admin/rankings">Rankings</Link>
          <Link href="/" target="_blank">Ver sitio ↗</Link>
          <form action={signOut} style={{ marginTop: 16 }}>
            <button className="btn ghost" style={{ color: "#D9D2C5", borderColor: "#D9D2C5", width: "100%" }}>
              Cerrar sesión
            </button>
          </form>
        </nav>
      </aside>
      <main className="admin-main">{children}</main>
    </div>
  );
}
