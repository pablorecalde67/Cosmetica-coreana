import Link from "next/link";
import { SiteHeader } from "@/components/SiteHeader";
import { SiteFooter } from "@/components/SiteFooter";
import { SearchBar } from "@/components/SearchBar";
import { ProductCard } from "@/components/ProductCard";
import { CategoryIcon } from "@/components/icons";
import { formatPrice, lowestOffer } from "@/lib/format";
import {
  getCategories,
  getFeaturedProducts,
  getBestPrices,
  getBrands,
  getStores,
  getRankingBySlug,
} from "@/lib/queries";

export default async function HomePage({
  searchParams,
}: {
  searchParams: { sort?: string };
}) {
  const [categories, featured, bestPrices, brands, stores, topSerums] = await Promise.all([
    getCategories(),
    getFeaturedProducts(),
    getBestPrices(10),
    getBrands(),
    getStores(),
    getRankingBySlug("serums"),
  ]);

  return (
    <>
      <SiteHeader />

      <section className="hero">
        <div className="hero-mark">뷰티</div>
        <div className="wrap">
          <span className="eyebrow">Ciudad del Este · Skincare &amp; K-Beauty</span>
          <h1>Cosmética coreana en <em>Ciudad del Este</em></h1>
          <p className="sub">
            Encontrá los mejores productos, precios y tiendas de K-Beauty en un solo lugar.
            Buscá, compará y contactá al vendedor en pocos pasos.
          </p>
          <SearchBar />
        </div>
      </section>

      <section className="block" id="categorias">
        <div className="wrap">
          <div className="section-head">
            <div>
              <span className="eyebrow">Explorar</span>
              <h2>Categorías</h2>
            </div>
          </div>
          <div className="cat-row">
            {categories.map((c) => (
              <Link key={c.id} href={`/categoria/${c.slug}`} className="cat-tile">
                <span className="ring"><CategoryIcon icon={c.icon} size={32} /></span>
                <span>{c.name}</span>
              </Link>
            ))}
          </div>
        </div>
      </section>

      <section className="block" id="destacados">
        <div className="wrap">
          <div className="section-head">
            <div>
              <span className="eyebrow">Selección editorial</span>
              <h2>Productos destacados</h2>
              <p>Una curaduría de los productos más buscados de la temporada, con precio, tienda y disponibilidad en tiempo real.</p>
            </div>
          </div>
          <div className="grid">
            {featured.map((p) => <ProductCard key={p.id} product={p} />)}
          </div>
        </div>
      </section>

      <section className="block" id="precios">
        <div className="wrap">
          <div className="section-head">
            <div>
              <span className="eyebrow">Comparativa</span>
              <h2>Los mejores precios de K-Beauty en CDE</h2>
              <p>Precios más bajos verificados entre todas las tiendas cargadas en la plataforma.</p>
            </div>
          </div>
          <div className="price-list">
            {bestPrices.map((p, i) => {
              const offer = lowestOffer(p.product_prices);
              if (!offer) return null;
              return (
                <Link key={p.id} href={`/producto/${p.slug}`} className="price-row">
                  <div className="rank mono">{String(i + 1).padStart(2, "0")}</div>
                  <div>
                    <div className="pbrand">{p.brand?.name}</div>
                    <div className="pname">{p.name}</div>
                  </div>
                  <div className="pstore">{offer.store?.name}</div>
                  <div className="pprice">{formatPrice(offer.price_usd)}</div>
                </Link>
              );
            })}
          </div>
        </div>
      </section>

      <section className="block" id="marcas">
        <div className="wrap">
          <div className="section-head">
            <div>
              <span className="eyebrow">Catálogo</span>
              <h2>Marcas</h2>
            </div>
            <Link href="/marcas" className="see-all">Ver todas →</Link>
          </div>
          <div className="brand-grid">
            {brands.slice(0, 16).map((b) => (
              <Link key={b.id} href={`/marcas/${b.slug}`} className="brand-pill">{b.name}</Link>
            ))}
          </div>
        </div>
      </section>

      <section className="block" id="tiendas">
        <div className="wrap">
          <div className="section-head">
            <div>
              <span className="eyebrow">Dónde comprar</span>
              <h2>Tiendas de Ciudad del Este</h2>
            </div>
            <Link href="/tiendas/ciudad-del-este" className="see-all">Ver todas →</Link>
          </div>
          <div className="store-grid">
            {stores.slice(0, 3).map((s) => (
              <div className="store-card" key={s.id}>
                <div className="sname">{s.name}</div>
                <div className="saddr">{s.address}</div>
                <div className="store-actions">
                  <a className="primary" href={`https://wa.me/${s.whatsapp}`} target="_blank">WhatsApp</a>
                  <Link href={`/tiendas/${s.slug}`}>Ver catálogo</Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="block" id="rankings">
        <div className="wrap">
          <div className="section-head">
            <div>
              <span className="eyebrow">Lo más elegido</span>
              <h2>{topSerums.ranking?.label ?? "Rankings"}</h2>
            </div>
            <Link href="/rankings" className="see-all">Ver todos los rankings →</Link>
          </div>
          <ol className="rank-list">
            {topSerums.products.map((p) => {
              const offer = lowestOffer(p.product_prices);
              return (
                <li key={p.id}>
                  <div>
                    <div className="pbrand">{p.brand?.name}</div>
                    <div>{p.name}</div>
                  </div>
                  {offer && <div className="rprice">{formatPrice(offer.price_usd)}</div>}
                </li>
              );
            })}
          </ol>
        </div>
      </section>

      <SiteFooter />
    </>
  );
}
