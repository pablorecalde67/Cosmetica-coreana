import Link from "next/link";
import { SiteHeader } from "@/components/SiteHeader";
import { SiteFooter } from "@/components/SiteFooter";
import { getBrands } from "@/lib/queries";

export const metadata = { title: "Marcas de K-Beauty en Ciudad del Este" };

export default async function BrandsPage() {
  const brands = await getBrands();
  return (
    <>
      <SiteHeader />
      <section className="block">
        <div className="wrap">
          <div className="section-head">
            <div><span className="eyebrow">Catálogo completo</span><h2>Marcas</h2></div>
          </div>
          <div className="brand-grid">
            {brands.map((b) => (
              <Link key={b.id} href={`/marcas/${b.slug}`} className="brand-pill">{b.name}</Link>
            ))}
          </div>
        </div>
      </section>
      <SiteFooter />
    </>
  );
}
