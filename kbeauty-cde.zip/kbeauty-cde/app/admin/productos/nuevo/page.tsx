import { ProductForm } from "@/components/admin/ProductForm";
import { getBrands, getCategories } from "@/lib/queries";

export default async function NewProductPage() {
  const [brands, categories] = await Promise.all([getBrands(), getCategories()]);
  return (
    <div>
      <h2 style={{ fontSize: "1.5rem", marginBottom: 20 }}>Nuevo producto</h2>
      <ProductForm brands={brands} categories={categories} />
    </div>
  );
}
