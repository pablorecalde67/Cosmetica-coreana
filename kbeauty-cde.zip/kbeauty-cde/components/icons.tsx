const PATHS: Record<string, string> = {
  limpieza: '<circle cx="12" cy="12" r="8"/><path d="M8 12h8M12 8v8"/>',
  tonicos: '<path d="M9 3h6l1 4-2 3v10a1 1 0 0 1-1 1h-2a1 1 0 0 1-1-1V10L8 7z"/>',
  esencias: '<circle cx="12" cy="14" r="6"/><path d="M12 8V4M10 4h4"/>',
  serums: '<path d="M9 2h6v6l3 6a3 3 0 0 1-3 5H9a3 3 0 0 1-3-5l3-6z"/>',
  cremas: '<path d="M5 10a7 7 0 0 1 14 0v7a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2z"/><path d="M9 4h6"/>',
  spf: '<circle cx="12" cy="12" r="4"/><path d="M12 3v2M12 19v2M4.2 4.2l1.4 1.4M18.4 18.4l1.4 1.4M3 12h2M19 12h2M4.2 19.8l1.4-1.4M18.4 5.6l1.4-1.4"/>',
  mascarillas: '<path d="M12 3c4 3 6 6 6 10a6 6 0 0 1-12 0c0-4 2-7 6-10z"/>',
  antiage: '<path d="M4 12a8 8 0 1 1 8 8"/><path d="M12 8v4l3 2"/>',
  acne: '<circle cx="12" cy="12" r="8"/><circle cx="9" cy="10" r="1"/><circle cx="15" cy="9" r="1"/><circle cx="13" cy="14" r="1"/>',
  sensible: '<path d="M12 21s-7-4.6-7-10a4.8 4.8 0 0 1 7-4.2A4.8 4.8 0 0 1 19 11c0 5.4-7 10-7 10z"/>',
};

export function CategoryIcon({ icon, size = 24 }: { icon: string | null | undefined; size?: number }) {
  const path = (icon && PATHS[icon]) || PATHS.esencias;
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="#1D1912"
      strokeWidth={1.4}
      strokeLinecap="round"
      strokeLinejoin="round"
      dangerouslySetInnerHTML={{ __html: path }}
    />
  );
}

export const ART_BG = ["#E7CFC3", "#DCE2D2", "#EFE7D8", "#D9C9BE", "#E2E6D9", "#EAD9C9"];

export function artColor(seed: string) {
  let hash = 0;
  for (let i = 0; i < seed.length; i++) hash = (hash * 31 + seed.charCodeAt(i)) >>> 0;
  return ART_BG[hash % ART_BG.length];
}
