import Link from "next/link";

export function SiteFooter() {
  return (
    <footer>
      <div className="wrap">
        <div className="foot-grid">
          <div>
            <h3>CDE Kbeauty</h3>
            <p>El buscador y comparador de cosmética coreana en Ciudad del Este. Productos, precios, stock y tiendas — actualizado por la comunidad de comercios locales.</p>
          </div>
          <div>
            <h3>Explorar</h3>
            <ul>
              <li><Link href="/marcas">Marcas</Link></li>
              <li><Link href="/tiendas/ciudad-del-este">Tiendas</Link></li>
              <li><Link href="/rankings">Rankings</Link></li>
            </ul>
          </div>
          <div>
            <h3>Para comercios</h3>
            <ul>
              <li><Link href="/admin/login">Panel de administración</Link></li>
            </ul>
          </div>
        </div>
        <div className="foot-bottom">
          <span>© 2026 CDE Kbeauty · Ciudad del Este, Paraguay</span>
          <span>Precios de referencia en USD</span>
        </div>
      </div>
    </footer>
  );
}
