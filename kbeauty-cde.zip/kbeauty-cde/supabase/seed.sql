-- ============================================================
-- CDE KBEAUTY — DATOS DE EJEMPLO
-- Ejecutar DESPUÉS de schema.sql. Es seguro re-ejecutar
-- (usa ON CONFLICT DO NOTHING en las claves únicas).
-- ============================================================

-- ---------- CATEGORIAS ----------
insert into categories (name, slug, icon, sort_order) values
  ('Limpieza','limpieza','limpieza',1),
  ('Tónicos','tonicos','tonicos',2),
  ('Esencias','esencias','esencias',3),
  ('Sérums','serums','serums',4),
  ('Cremas','cremas','cremas',5),
  ('Protector solar','spf','spf',6),
  ('Mascarillas','mascarillas','mascarillas',7),
  ('Contorno de ojos','contorno-ojos','antiage',8),
  ('Antiage','antiage','antiage',9),
  ('Acné','acne','acne',10),
  ('Piel sensible','sensible','sensible',11),
  ('Hidratación','hidratacion','esencias',12),
  ('Maquillaje','maquillaje','mascarillas',13),
  ('Dispositivos de skincare','dispositivos','cremas',14)
on conflict (slug) do nothing;

-- ---------- MARCAS ----------
insert into brands (name, slug) values
  ('COSRX','cosrx'),
  ('Beauty of Joseon','beauty-of-joseon'),
  ('Anua','anua'),
  ('Medicube','medicube'),
  ('Torriden','torriden'),
  ('SKIN1004','skin1004'),
  ('Round Lab','round-lab'),
  ('Isntree','isntree'),
  ('Dr. Althea','dr-althea'),
  ('Some By Mi','some-by-mi'),
  ('Purito','purito'),
  ('Laneige','laneige'),
  ('Haruharu Wonder','haruharu-wonder'),
  ('Mixsoon','mixsoon'),
  ('Jumiso','jumiso'),
  ('Klairs','klairs'),
  ('Abib','abib'),
  ('IUNIK','iunik'),
  ('Benton','benton'),
  ('Pyunkang Yul','pyunkang-yul')
on conflict (slug) do nothing;

-- ---------- TIENDAS ----------
insert into stores (name, slug, address, whatsapp, instagram) values
  ('Bella Corea Store','bella-corea-store','Shopping China, Local 42','595981000001','@bellacoreastore'),
  ('Seoul Beauty CDE','seoul-beauty-cde','Av. San Blas y Curupayty, Galería K','595981000002','@seoulbeautycde'),
  ('K-Glow Paraguay','k-glow-paraguay','Monalisa Shopping, Local 15','595981000003','@kglow.py'),
  ('Petit Beauty CDE','petit-beauty-cde','Zona franca, Local 8','595981000004','@petitbeautycde'),
  ('Glow House PY','glow-house-py','Shopping Beira Río, Local 3','595981000005','@glowhouse.py')
on conflict (slug) do nothing;

-- ---------- PRODUCTOS ----------
insert into products (name, slug, brand_id, category_id, tagline, skin_type, key_ingredients, is_featured, is_new, popularity) values
  ('Advanced Snail 96 Mucin Power Essence','cosrx-advanced-snail-96-mucin-power-essence',
    (select id from brands where slug='cosrx'), (select id from categories where slug='esencias'),
    'Repara e hidrata con 96% de mucina de caracol filtrada','Seca / Sensible','Mucina de caracol, betaína', true, false, 98),
  ('Glow Serum Ginseng + Snail Mucin','beauty-of-joseon-glow-serum',
    (select id from brands where slug='beauty-of-joseon'), (select id from categories where slug='serums'),
    'Luminosidad y firmeza con ginseng y mucina','Todo tipo','Ginseng, mucina de caracol', true, false, 91),
  ('Relief Sun Rice + Probiotics SPF50+','beauty-of-joseon-relief-sun-rice',
    (select id from brands where slug='beauty-of-joseon'), (select id from categories where slug='spf'),
    'Protección solar ligera con arroz y probióticos','Todo tipo','Extracto de arroz, probióticos', true, true, 120),
  ('Zero Pore Pad','medicube-zero-pore-pad',
    (select id from brands where slug='medicube'), (select id from categories where slug='tonicos'),
    'Exfoliante en pads para minimizar poros','Grasa / Mixta','Ácido salicílico, niacinamida', false, false, 76),
  ('Collagen Jella Cream','medicube-collagen-jella-cream',
    (select id from brands where slug='medicube'), (select id from categories where slug='cremas'),
    'Crema efecto jalea con colágeno de bajo peso molecular','Seca / Madura','Colágeno hidrolizado', false, false, 64),
  ('Heartleaf 77% Soothing Toner','anua-heartleaf-77-soothing-toner',
    (select id from brands where slug='anua'), (select id from categories where slug='tonicos'),
    'Calma e hidrata con extracto de heartleaf al 77%','Sensible / Acné','Extracto de heartleaf', true, false, 112),
  ('Heartleaf Pore Control Cleansing Oil','anua-heartleaf-cleansing-oil',
    (select id from brands where slug='anua'), (select id from categories where slug='limpieza'),
    'Aceite limpiador que controla la obstrucción de poros','Grasa / Mixta','Extracto de heartleaf, aceites vegetales', false, false, 58),
  ('Dive-In Low Molecular Hyaluronic Acid Serum','torriden-dive-in-serum',
    (select id from brands where slug='torriden'), (select id from categories where slug='serums'),
    'Hidratación profunda con 5 tipos de ácido hialurónico','Deshidratada','Ácido hialurónico', false, false, 83),
  ('Madagascar Centella Ampoule','skin1004-madagascar-centella-ampoule',
    (select id from brands where slug='skin1004'), (select id from categories where slug='esencias'),
    'Calma e uniforma la piel con 100% centella asiática','Sensible / Acné','Centella asiática', true, false, 105),
  ('1025 Dokdo Cleanser','round-lab-dokdo-cleanser',
    (select id from brands where slug='round-lab'), (select id from categories where slug='limpieza'),
    'Limpiador suave en gel con minerales marinos','Todo tipo','Agua mineral profunda', false, false, 44),
  ('Hyaluronic Acid Toner Serum','isntree-hyaluronic-toner-serum',
    (select id from brands where slug='isntree'), (select id from categories where slug='tonicos'),
    'Tónico-sérum de hidratación en múltiples capas','Deshidratada','Ácido hialurónico', false, false, 39),
  ('345 Relief Cream','dr-althea-345-relief-cream',
    (select id from brands where slug='dr-althea'), (select id from categories where slug='cremas'),
    'Crema calmante de barrera para pieles reactivas','Sensible','Panthenol, madeca-asiático', false, false, 52),
  ('AHA BHA PHA 30 Days Miracle Toner','some-by-mi-miracle-toner',
    (select id from brands where slug='some-by-mi'), (select id from categories where slug='tonicos'),
    'Tónico exfoliante para piel con acné y textura irregular','Grasa / Acné','AHA, BHA, PHA', true, false, 97),
  ('Centella Green Level Unscented Sun SPF50+','purito-centella-sun-spf50',
    (select id from brands where slug='purito'), (select id from categories where slug='spf'),
    'Protector solar sin fragancia para piel sensible','Sensible','Centella asiática', false, false, 71),
  ('Water Sleeping Mask','laneige-water-sleeping-mask',
    (select id from brands where slug='laneige'), (select id from categories where slug='mascarillas'),
    'Mascarilla nocturna de hidratación intensiva','Deshidratada','Complejo hidro-ionizado', true, false, 88),
  ('Black Rice Hyaluronic Toner','haruharu-wonder-black-rice-toner',
    (select id from brands where slug='haruharu-wonder'), (select id from categories where slug='tonicos'),
    'Tónico untuoso de arroz negro para piel opaca','Madura / Opaca','Arroz negro fermentado', false, true, 46),
  ('Bean Essence','mixsoon-bean-essence',
    (select id from brands where slug='mixsoon'), (select id from categories where slug='esencias'),
    'Esencia fermentada de porotos negros para elasticidad','Madura','Extracto de poroto negro', false, true, 33),
  ('Freshly Juiced Vitamin Drop','klairs-vitamin-drop',
    (select id from brands where slug='klairs'), (select id from categories where slug='serums'),
    'Sérum de vitamina C para luminosidad y manchas','Opaca / Manchas','Vitamina C estabilizada', true, false, 67),
  ('Heartleaf Spot Patch','abib-heartleaf-spot-patch',
    (select id from brands where slug='abib'), (select id from categories where slug='sensible'),
    'Parches calmantes para brotes puntuales','Acné','Extracto de heartleaf', false, false, 29),
  ('Centella Calming Serum','iunik-centella-calming-serum',
    (select id from brands where slug='iunik'), (select id from categories where slug='esencias'),
    'Sérum calmante de alta concentración de centella','Sensible / Acné','Centella asiática', false, false, 41),
  ('Snail Bee High Content Steam Cream','benton-snail-bee-steam-cream',
    (select id from brands where slug='benton'), (select id from categories where slug='cremas'),
    'Crema reparadora con mucina de caracol y veneno de abeja','Mixta / Sensible','Mucina de caracol, extracto de abeja', false, false, 37),
  ('Essence Toner','pyunkang-yul-essence-toner',
    (select id from brands where slug='pyunkang-yul'), (select id from categories where slug='tonicos'),
    'Tónico minimalista de baja irritación para uso diario','Todo tipo','Extracto de ciruela silvestre', false, false, 54)
on conflict (slug) do nothing;

-- ---------- PRECIOS Y STOCK POR TIENDA ----------
insert into product_prices (product_id, store_id, price_usd, stock) values
  ((select id from products where slug='cosrx-advanced-snail-96-mucin-power-essence'),(select id from stores where slug='bella-corea-store'),24,'in'),
  ((select id from products where slug='cosrx-advanced-snail-96-mucin-power-essence'),(select id from stores where slug='seoul-beauty-cde'),22.5,'in'),
  ((select id from products where slug='cosrx-advanced-snail-96-mucin-power-essence'),(select id from stores where slug='k-glow-paraguay'),26,'low'),

  ((select id from products where slug='beauty-of-joseon-glow-serum'),(select id from stores where slug='bella-corea-store'),19,'in'),
  ((select id from products where slug='beauty-of-joseon-glow-serum'),(select id from stores where slug='petit-beauty-cde'),18,'in'),

  ((select id from products where slug='beauty-of-joseon-relief-sun-rice'),(select id from stores where slug='bella-corea-store'),17,'in'),
  ((select id from products where slug='beauty-of-joseon-relief-sun-rice'),(select id from stores where slug='seoul-beauty-cde'),16.5,'in'),
  ((select id from products where slug='beauty-of-joseon-relief-sun-rice'),(select id from stores where slug='glow-house-py'),18,'in'),

  ((select id from products where slug='medicube-zero-pore-pad'),(select id from stores where slug='k-glow-paraguay'),29,'in'),
  ((select id from products where slug='medicube-zero-pore-pad'),(select id from stores where slug='petit-beauty-cde'),27.5,'low'),

  ((select id from products where slug='medicube-collagen-jella-cream'),(select id from stores where slug='k-glow-paraguay'),33,'in'),

  ((select id from products where slug='anua-heartleaf-77-soothing-toner'),(select id from stores where slug='bella-corea-store'),16,'in'),
  ((select id from products where slug='anua-heartleaf-77-soothing-toner'),(select id from stores where slug='seoul-beauty-cde'),15,'in'),
  ((select id from products where slug='anua-heartleaf-77-soothing-toner'),(select id from stores where slug='glow-house-py'),16.5,'in'),

  ((select id from products where slug='anua-heartleaf-cleansing-oil'),(select id from stores where slug='seoul-beauty-cde'),18,'in'),

  ((select id from products where slug='torriden-dive-in-serum'),(select id from stores where slug='petit-beauty-cde'),15,'in'),
  ((select id from products where slug='torriden-dive-in-serum'),(select id from stores where slug='bella-corea-store'),16,'in'),

  ((select id from products where slug='skin1004-madagascar-centella-ampoule'),(select id from stores where slug='glow-house-py'),14,'in'),
  ((select id from products where slug='skin1004-madagascar-centella-ampoule'),(select id from stores where slug='k-glow-paraguay'),13.5,'in'),
  ((select id from products where slug='skin1004-madagascar-centella-ampoule'),(select id from stores where slug='petit-beauty-cde'),15,'low'),

  ((select id from products where slug='round-lab-dokdo-cleanser'),(select id from stores where slug='bella-corea-store'),14,'in'),

  ((select id from products where slug='isntree-hyaluronic-toner-serum'),(select id from stores where slug='seoul-beauty-cde'),13,'in'),

  ((select id from products where slug='dr-althea-345-relief-cream'),(select id from stores where slug='k-glow-paraguay'),28,'in'),
  ((select id from products where slug='dr-althea-345-relief-cream'),(select id from stores where slug='glow-house-py'),26.5,'in'),

  ((select id from products where slug='some-by-mi-miracle-toner'),(select id from stores where slug='bella-corea-store'),15,'in'),
  ((select id from products where slug='some-by-mi-miracle-toner'),(select id from stores where slug='petit-beauty-cde'),14,'in'),
  ((select id from products where slug='some-by-mi-miracle-toner'),(select id from stores where slug='seoul-beauty-cde'),15.5,'in'),

  ((select id from products where slug='purito-centella-sun-spf50'),(select id from stores where slug='glow-house-py'),15,'in'),

  ((select id from products where slug='laneige-water-sleeping-mask'),(select id from stores where slug='k-glow-paraguay'),34,'in'),
  ((select id from products where slug='laneige-water-sleeping-mask'),(select id from stores where slug='bella-corea-store'),32,'low'),

  ((select id from products where slug='haruharu-wonder-black-rice-toner'),(select id from stores where slug='petit-beauty-cde'),17,'in'),

  ((select id from products where slug='mixsoon-bean-essence'),(select id from stores where slug='seoul-beauty-cde'),19,'in'),

  ((select id from products where slug='klairs-vitamin-drop'),(select id from stores where slug='bella-corea-store'),20,'in'),
  ((select id from products where slug='klairs-vitamin-drop'),(select id from stores where slug='glow-house-py'),19,'in'),

  ((select id from products where slug='abib-heartleaf-spot-patch'),(select id from stores where slug='k-glow-paraguay'),9,'in'),

  ((select id from products where slug='iunik-centella-calming-serum'),(select id from stores where slug='petit-beauty-cde'),16,'out'),

  ((select id from products where slug='benton-snail-bee-steam-cream'),(select id from stores where slug='seoul-beauty-cde'),18,'in'),

  ((select id from products where slug='pyunkang-yul-essence-toner'),(select id from stores where slug='bella-corea-store'),12,'in'),
  ((select id from products where slug='pyunkang-yul-essence-toner'),(select id from stores where slug='petit-beauty-cde'),11.5,'in')
on conflict (product_id, store_id) do nothing;

-- ---------- RANKINGS ----------
insert into rankings (slug, label, sort_order) values
  ('serums','Top sérums',1),
  ('spf','Top protectores solares',2),
  ('antiage','Top antiage',3),
  ('acne','Top para acné',4),
  ('budget','Menos de US$20',5)
on conflict (slug) do nothing;

insert into ranking_items (ranking_id, product_id, position) values
  ((select id from rankings where slug='serums'),(select id from products where slug='cosrx-advanced-snail-96-mucin-power-essence'),1),
  ((select id from rankings where slug='serums'),(select id from products where slug='beauty-of-joseon-glow-serum'),2),
  ((select id from rankings where slug='serums'),(select id from products where slug='torriden-dive-in-serum'),3),
  ((select id from rankings where slug='serums'),(select id from products where slug='klairs-vitamin-drop'),4),

  ((select id from rankings where slug='spf'),(select id from products where slug='beauty-of-joseon-relief-sun-rice'),1),
  ((select id from rankings where slug='spf'),(select id from products where slug='purito-centella-sun-spf50'),2),

  ((select id from rankings where slug='antiage'),(select id from products where slug='beauty-of-joseon-glow-serum'),1),
  ((select id from rankings where slug='antiage'),(select id from products where slug='medicube-collagen-jella-cream'),2),
  ((select id from rankings where slug='antiage'),(select id from products where slug='dr-althea-345-relief-cream'),3),
  ((select id from rankings where slug='antiage'),(select id from products where slug='klairs-vitamin-drop'),4),

  ((select id from rankings where slug='acne'),(select id from products where slug='skin1004-madagascar-centella-ampoule'),1),
  ((select id from rankings where slug='acne'),(select id from products where slug='some-by-mi-miracle-toner'),2),
  ((select id from rankings where slug='acne'),(select id from products where slug='abib-heartleaf-spot-patch'),3),
  ((select id from rankings where slug='acne'),(select id from products where slug='iunik-centella-calming-serum'),4),

  ((select id from rankings where slug='budget'),(select id from products where slug='anua-heartleaf-77-soothing-toner'),1),
  ((select id from rankings where slug='budget'),(select id from products where slug='anua-heartleaf-cleansing-oil'),2),
  ((select id from rankings where slug='budget'),(select id from products where slug='skin1004-madagascar-centella-ampoule'),3),
  ((select id from rankings where slug='budget'),(select id from products where slug='round-lab-dokdo-cleanser'),4),
  ((select id from rankings where slug='budget'),(select id from products where slug='isntree-hyaluronic-toner-serum'),5),
  ((select id from rankings where slug='budget'),(select id from products where slug='purito-centella-sun-spf50'),6),
  ((select id from rankings where slug='budget'),(select id from products where slug='haruharu-wonder-black-rice-toner'),7),
  ((select id from rankings where slug='budget'),(select id from products where slug='abib-heartleaf-spot-patch'),8),
  ((select id from rankings where slug='budget'),(select id from products where slug='benton-snail-bee-steam-cream'),9),
  ((select id from rankings where slug='budget'),(select id from products where slug='pyunkang-yul-essence-toner'),10)
on conflict (ranking_id, product_id) do nothing;
