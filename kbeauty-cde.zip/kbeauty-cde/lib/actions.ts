"use server";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { createClient } from "./supabase/server";

function slugify(text: string) {
  return text
    .toString()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)+/g, "");
}

// ---------- AUTH ----------
export async function signIn(formData: FormData) {
  const supabase = createClient();
  const email = String(formData.get("email"));
  const password = String(formData.get("password"));
  const { error } = await supabase.auth.signInWithPassword({ email, password });
  if (error) redirect("/admin/login?error=1");
  redirect("/admin");
}

export async function signOut() {
  const supabase = createClient();
  await supabase.auth.signOut();
  redirect("/admin/login");
}

// ---------- PRODUCTOS ----------
export async function upsertProduct(formData: FormData) {
  const supabase = createClient();
  const id = formData.get("id") as string | null;
  const name = String(formData.get("name"));
  const payload = {
    name,
    slug: slugify(String(formData.get("slug") || name)),
    brand_id: (formData.get("brand_id") as string) || null,
    category_id: (formData.get("category_id") as string) || null,
    tagline: (formData.get("tagline") as string) || null,
    description: (formData.get("description") as string) || null,
    benefits: (formData.get("benefits") as string) || null,
    skin_type: (formData.get("skin_type") as string) || null,
    key_ingredients: (formData.get("key_ingredients") as string) || null,
    how_to_use: (formData.get("how_to_use") as string) || null,
    image_url: (formData.get("image_url") as string) || null,
    is_featured: formData.get("is_featured") === "on",
    is_new: formData.get("is_new") === "on",
    popularity: Number(formData.get("popularity") || 0),
  };

  if (id) {
    await supabase.from("products").update(payload).eq("id", id);
  } else {
    await supabase.from("products").insert(payload);
  }
  revalidatePath("/admin/productos");
  revalidatePath("/");
  redirect("/admin/productos");
}

export async function deleteProduct(formData: FormData) {
  const supabase = createClient();
  const id = String(formData.get("id"));
  await supabase.from("products").delete().eq("id", id);
  revalidatePath("/admin/productos");
  revalidatePath("/");
}

// ---------- MARCAS ----------
export async function createBrand(formData: FormData) {
  const supabase = createClient();
  const name = String(formData.get("name"));
  await supabase.from("brands").insert({ name, slug: slugify(name) });
  revalidatePath("/admin/marcas");
  revalidatePath("/marcas");
}

export async function deleteBrand(formData: FormData) {
  const supabase = createClient();
  const id = String(formData.get("id"));
  await supabase.from("brands").delete().eq("id", id);
  revalidatePath("/admin/marcas");
  revalidatePath("/marcas");
}

// ---------- TIENDAS ----------
export async function upsertStore(formData: FormData) {
  const supabase = createClient();
  const id = formData.get("id") as string | null;
  const name = String(formData.get("name"));
  const payload = {
    name,
    slug: slugify(String(formData.get("slug") || name)),
    address: (formData.get("address") as string) || null,
    whatsapp: (formData.get("whatsapp") as string) || null,
    instagram: (formData.get("instagram") as string) || null,
    website: (formData.get("website") as string) || null,
  };
  if (id) {
    await supabase.from("stores").update(payload).eq("id", id);
  } else {
    await supabase.from("stores").insert(payload);
  }
  revalidatePath("/admin/tiendas");
  revalidatePath("/tiendas/ciudad-del-este");
}

export async function deleteStore(formData: FormData) {
  const supabase = createClient();
  const id = String(formData.get("id"));
  await supabase.from("stores").delete().eq("id", id);
  revalidatePath("/admin/tiendas");
}

// ---------- PRECIOS Y STOCK ----------
export async function upsertPrice(formData: FormData) {
  const supabase = createClient();
  const product_id = String(formData.get("product_id"));
  const store_id = String(formData.get("store_id"));
  const price_usd = Number(formData.get("price_usd"));
  const stock = String(formData.get("stock"));
  await supabase
    .from("product_prices")
    .upsert({ product_id, store_id, price_usd, stock }, { onConflict: "product_id,store_id" });
  revalidatePath("/admin/precios");
  revalidatePath("/");
}

export async function deletePrice(formData: FormData) {
  const supabase = createClient();
  const id = String(formData.get("id"));
  await supabase.from("product_prices").delete().eq("id", id);
  revalidatePath("/admin/precios");
}

// ---------- RANKINGS ----------
export async function addRankingItem(formData: FormData) {
  const supabase = createClient();
  const ranking_id = String(formData.get("ranking_id"));
  const product_id = String(formData.get("product_id"));
  const position = Number(formData.get("position") || 99);
  await supabase.from("ranking_items").upsert(
    { ranking_id, product_id, position },
    { onConflict: "ranking_id,product_id" }
  );
  revalidatePath("/admin/rankings");
  revalidatePath("/rankings");
}

export async function removeRankingItem(formData: FormData) {
  const supabase = createClient();
  const id = String(formData.get("id"));
  await supabase.from("ranking_items").delete().eq("id", id);
  revalidatePath("/admin/rankings");
  revalidatePath("/rankings");
}
