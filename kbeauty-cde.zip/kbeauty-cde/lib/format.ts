import type { Product, ProductPrice, Stock } from "./types";

export const RATES: Record<string, number> = { USD: 1, GS: 7500, ARS: 1450 };
export const SYMB: Record<string, string> = { USD: "US$", GS: "₲", ARS: "AR$" };

export function formatPrice(usd: number, currency: string = "USD") {
  const v = usd * (RATES[currency] ?? 1);
  const decimals = currency === "USD" ? 2 : 0;
  return (
    (SYMB[currency] ?? "US$") +
    v.toLocaleString("es-PY", { minimumFractionDigits: decimals, maximumFractionDigits: decimals })
  );
}

export function lowestOffer(prices: ProductPrice[] | undefined): ProductPrice | null {
  if (!prices || prices.length === 0) return null;
  const available = prices.filter((p) => p.stock !== "out");
  const pool = available.length ? available : prices;
  return pool.reduce((a, b) => (b.price_usd < a.price_usd ? b : a));
}

export function stockLabel(stock: Stock) {
  return stock === "in" ? "En stock" : stock === "low" ? "Poco stock" : "Sin stock";
}

export function productHref(p: Pick<Product, "slug">) {
  return `/producto/${p.slug}`;
}
