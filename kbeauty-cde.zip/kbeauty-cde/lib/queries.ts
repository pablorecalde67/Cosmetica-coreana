import { createClient } from "./supabase/server";
import type { Brand, Category, Product, Ranking, Store } from "./types";

const PRODUCT_SELECT = `
  *,
  brand:brands(*),
  category:categories(*),
  product_prices(*, store:stores(*))
`;

export async function getCategories(): Promise<Category[]> {
  const supabase = createClient();
  const { data } = await supabase.from("categories").select("*").order("sort_order");
  return data ?? [];
}

export async function getBrands(): Promise<Brand[]> {
  const supabase = createClient();
  const { data } = await supabase.from("brands").select("*").order("name");
  return data ?? [];
}

export async function getStores(): Promise<Store[]> {
  const supabase = createClient();
  const { data } = await supabase.from("stores").select("*").order("name");
  return data ?? [];
}

export async function getFeaturedProducts(): Promise<Product[]> {
  const supabase = createClient();
  const { data } = await supabase
    .from("products")
    .select(PRODUCT_SELECT)
    .eq("is_featured", true)
    .limit(8);
  return (data as unknown as Product[]) ?? [];
}

export async function getAllProductsForListing(): Promise<Product[]> {
  const supabase = createClient();
  const { data } = await supabase.from("products").select(PRODUCT_SELECT);
  return (data as unknown as Product[]) ?? [];
}

export async function searchProducts(term: string): Promise<Product[]> {
  const supabase = createClient();
  const { data } = await supabase
    .from("products")
    .select(PRODUCT_SELECT)
    .or(`name.ilike.%${term}%,tagline.ilike.%${term}%`);
  return (data as unknown as Product[]) ?? [];
}

export async function getProductBySlug(slug: string): Promise<Product | null> {
  const supabase = createClient();
  const { data } = await supabase.from("products").select(PRODUCT_SELECT).eq("slug", slug).single();
  return (data as unknown as Product) ?? null;
}

export async function getProductsByBrandSlug(slug: string): Promise<{ brand: Brand | null; products: Product[] }> {
  const supabase = createClient();
  const { data: brand } = await supabase.from("brands").select("*").eq("slug", slug).single();
  if (!brand) return { brand: null, products: [] };
  const { data: products } = await supabase.from("products").select(PRODUCT_SELECT).eq("brand_id", brand.id);
  return { brand, products: (products as unknown as Product[]) ?? [] };
}

export async function getProductsByCategorySlug(slug: string): Promise<{ category: Category | null; products: Product[] }> {
  const supabase = createClient();
  const { data: category } = await supabase.from("categories").select("*").eq("slug", slug).single();
  if (!category) return { category: null, products: [] };
  const { data: products } = await supabase.from("products").select(PRODUCT_SELECT).eq("category_id", category.id);
  return { category, products: (products as unknown as Product[]) ?? [] };
}

export async function getStoreBySlug(slug: string): Promise<{ store: Store | null; products: Product[] }> {
  const supabase = createClient();
  const { data: store } = await supabase.from("stores").select("*").eq("slug", slug).single();
  if (!store) return { store: null, products: [] };
  const { data: prices } = await supabase
    .from("product_prices")
    .select(`price_usd, stock, product:products(${PRODUCT_SELECT})`)
    .eq("store_id", store.id);
  const products = (prices ?? []).map((row: any) => row.product) as Product[];
  return { store, products };
}

export async function getRankings(): Promise<Ranking[]> {
  const supabase = createClient();
  const { data } = await supabase.from("rankings").select("*").order("sort_order");
  return data ?? [];
}

export async function getRankingBySlug(slug: string): Promise<{ ranking: Ranking | null; products: Product[] }> {
  const supabase = createClient();
  const { data: ranking } = await supabase.from("rankings").select("*").eq("slug", slug).single();
  if (!ranking) return { ranking: null, products: [] };
  const { data: items } = await supabase
    .from("ranking_items")
    .select(`position, product:products(${PRODUCT_SELECT})`)
    .eq("ranking_id", ranking.id)
    .order("position");
  const products = (items ?? []).map((row: any) => row.product) as Product[];
  return { ranking, products };
}

export async function getBestPrices(limit = 10): Promise<Product[]> {
  const supabase = createClient();
  const { data } = await supabase.from("products").select(PRODUCT_SELECT);
  const products = (data as unknown as Product[]) ?? [];
  return products
    .filter((p) => p.product_prices && p.product_prices.length > 0)
    .sort((a, b) => {
      const la = Math.min(...a.product_prices!.map((pp) => pp.price_usd));
      const lb = Math.min(...b.product_prices!.map((pp) => pp.price_usd));
      return la - lb;
    })
    .slice(0, limit);
}
