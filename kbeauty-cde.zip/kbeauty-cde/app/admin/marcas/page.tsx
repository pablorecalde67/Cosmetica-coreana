import { createClient } from "@/lib/supabase/server";
import { createBrand, deleteBrand } from "@/lib/actions";

export default async function AdminBrandsPage() {
  const supabase = createClient();
  const { data: brands } = await supabase.from("brands").select("*").order("name");

  return (
    <div>
      <h2 style={{ fontSize: "1.5rem", marginBottom: 20 }}>Marcas</h2>

      <form action={createBrand} style={{ display: "flex", gap: 10, marginBottom: 28, maxWidth: 420 }}>
        <input name="name" placeholder="Nombre de la nueva marca" required style={{ flex: 1, padding: 11, border: "1px solid var(--line)", borderRadius: 4, background: "var(--paper)" }} />
        <button className="btn" style={{ border: "none" }}>Agregar</button>
      </form>

      <table className="admin-table">
        <thead><tr><th>Nombre</th><th>Slug</th><th></th></tr></thead>
        <tbody>
          {(brands ?? []).map((b) => (
            <tr key={b.id}>
              <td>{b.name}</td>
              <td>{b.slug}</td>
              <td>
                <form action={deleteBrand}>
                  <input type="hidden" name="id" value={b.id} />
                  <button className="btn danger" style={{ padding: "4px 10px", fontSize: "0.78rem" }}>Borrar</button>
                </form>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
