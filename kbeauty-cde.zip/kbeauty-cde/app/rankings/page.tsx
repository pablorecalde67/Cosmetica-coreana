import Link from "next/link";
import { SiteHeader } from "@/components/SiteHeader";
import { SiteFooter } from "@/components/SiteFooter";
import { formatPrice, lowestOffer } from "@/lib/format";
import { getRankings, getRankingBySlug } from "@/lib/queries";

export const metadata = { title: "Rankings de K-Beauty en Ciudad del Este" };

export default async function RankingsPage({ searchParams }: { searchParams: { top?: string } }) {
  const rankings = await getRankings();
  const activeSlug = searchParams.top || rankings[0]?.slug;
  const { ranking, products } = await getRankingBySlug(activeSlug);

  return (
    <>
      <SiteHeader />
      <section className="block">
        <div className="wrap">
          <div className="section-head">
            <div><span className="eyebrow">Lo más elegido</span><h2>Rankings</h2></div>
          </div>
          <div className="rank-tabs">
            {rankings.map((r) => (
              <Link key={r.id} href={`/rankings?top=${r.slug}`} className={r.slug === activeSlug ? "active" : ""}>
                {r.label}
              </Link>
            ))}
          </div>
          <ol className="rank-list">
            {products.map((p) => {
              const offer = lowestOffer(p.product_prices);
              return (
                <li key={p.id}>
                  <div>
                    <div className="pbrand">{p.brand?.name}</div>
                    <Link href={`/producto/${p.slug}`}>{p.name}</Link>
                  </div>
                  {offer && <div className="rprice">{formatPrice(offer.price_usd)}</div>}
                </li>
              );
            })}
            {products.length === 0 && <div className="empty-state">Este ranking todavía no tiene productos.</div>}
          </ol>
        </div>
      </section>
      <SiteFooter />
    </>
  );
}
