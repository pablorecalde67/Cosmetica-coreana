import type { Metadata } from "next";
import { notFound } from "next/navigation";
import Link from "next/link";
import { SiteHeader } from "@/components/SiteHeader";
import { SiteFooter } from "@/components/SiteFooter";
import { CategoryIcon, artColor } from "@/components/icons";
import { formatPrice, stockLabel } from "@/lib/format";
import { getProductBySlug } from "@/lib/queries";

export async function generateMetadata({ params }: { params: { slug: string } }): Promise<Metadata> {
  const product = await getProductBySlug(params.slug);
  if (!product) return {};
  return {
    title: `${product.name} — ${product.brand?.name ?? ""}`,
    description: product.tagline ?? undefined,
  };
}

export default async function ProductPage({ params }: { params: { slug: string } }) {
  const product = await getProductBySlug(params.slug);
  if (!product) return notFound();

  const rows = [...(product.product_prices ?? [])].sort((a, b) => a.price_usd - b.price_usd);
  const best = rows[0];

  return (
    <>
      <SiteHeader />
      <section className="block">
        <div className="wrap">
          <div className="product-hero">
            <div className="product-art" style={{ background: artColor(product.id) }}>
              <CategoryIcon icon={product.category?.icon} size={80} />
            </div>
            <div>
              <span className="eyebrow">
                <Link href={`/marcas/${product.brand?.slug}`}>{product.brand?.name}</Link>
                {product.category && <> · <Link href={`/categoria/${product.category.slug}`}>{product.category.name}</Link></>}
              </span>
              <h1 style={{ fontSize: "2rem" }}>{product.name}</h1>
              <p style={{ color: "var(--ink-soft)", marginTop: 12 }}>{product.tagline}</p>

              <div className="pd-meta">
                {product.skin_type && <div><b>Tipo de piel:</b> {product.skin_type}</div>}
                {product.key_ingredients && <div><b>Ingredientes destacados:</b> {product.key_ingredients}</div>}
                {product.how_to_use && <div><b>Modo de uso:</b> {product.how_to_use}</div>}
              </div>

              {best && (
                <div style={{ marginTop: 18 }}>
                  <div className="price" style={{ fontSize: "1.6rem" }}>{formatPrice(best.price_usd)}</div>
                  <div style={{ fontSize: "0.82rem", color: "var(--ink-soft)" }}>
                    Mejor precio en {best.store?.name} · {stockLabel(best.stock)}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </section>

      <section className="block">
        <div className="wrap">
          <div className="section-head">
            <div>
              <span className="eyebrow">Comparador</span>
              <h2>Disponible en {rows.length} tienda{rows.length !== 1 ? "s" : ""}</h2>
            </div>
          </div>
          <div className="compare-wrap">
            <table className="compare">
              <thead>
                <tr><th>Tienda</th><th>Precio</th><th>Stock</th><th>Ubicación</th><th></th></tr>
              </thead>
              <tbody>
                {rows.map((r) => (
                  <tr key={r.id} className={r === best ? "best" : ""}>
                    <td>{r.store?.name}{r === best && <span style={{ color: "var(--blush)", fontSize: "0.7rem" }}> · mejor precio</span>}</td>
                    <td className="price">{formatPrice(r.price_usd)}</td>
                    <td>{stockLabel(r.stock)}</td>
                    <td>{r.store?.address}</td>
                    <td><a className="wa" href={`https://wa.me/${r.store?.whatsapp}`} target="_blank">WhatsApp</a></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </section>
      <SiteFooter />
    </>
  );
}
