import { SiteHeader } from "@/components/SiteHeader";
import { SiteFooter } from "@/components/SiteFooter";
import { SearchBar } from "@/components/SearchBar";
import { ProductCard } from "@/components/ProductCard";
import { searchProducts } from "@/lib/queries";

export const metadata = { title: "Buscar productos de K-Beauty" };

export default async function SearchPage({ searchParams }: { searchParams: { q?: string } }) {
  const q = searchParams.q ?? "";
  const results = q ? await searchProducts(q) : [];

  return (
    <>
      <SiteHeader />
      <section className="hero" style={{ padding: "40px 0" }}>
        <div className="wrap">
          <span className="eyebrow">Buscador</span>
          <h1 style={{ fontSize: "1.8rem" }}>Resultados para “{q}”</h1>
          <div style={{ marginTop: 20 }}><SearchBar /></div>
        </div>
      </section>
      <section className="block">
        <div className="wrap">
          <div className="grid">
            {results.map((p) => <ProductCard key={p.id} product={p} />)}
          </div>
          {q && results.length === 0 && (
            <div className="empty-state">No encontramos productos para “{q}”. Probá con otra marca o categoría.</div>
          )}
        </div>
      </section>
      <SiteFooter />
    </>
  );
}
