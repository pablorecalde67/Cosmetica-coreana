import Link from "next/link";
import { SiteHeader } from "@/components/SiteHeader";
import { SiteFooter } from "@/components/SiteFooter";
import { getStores, getAllProductsForListing } from "@/lib/queries";

export const metadata = { title: "Tiendas de cosmética coreana en Ciudad del Este" };

export default async function StoresPage() {
  const [stores, products] = await Promise.all([getStores(), getAllProductsForListing()]);
  return (
    <>
      <SiteHeader />
      <section className="block">
        <div className="wrap">
          <div className="section-head">
            <div>
              <span className="eyebrow">Dónde comprar</span>
              <h2>Tiendas de Ciudad del Este</h2>
              <p>Comercios verificados con stock actualizado, ubicación y contacto directo.</p>
            </div>
          </div>
          <div className="store-grid">
            {stores.map((s) => {
              const count = products.filter((p) => p.product_prices?.some((pp) => pp.store_id === s.id)).length;
              return (
                <div className="store-card" key={s.id}>
                  <div className="sname">{s.name}</div>
                  <div className="saddr">{s.address}</div>
                  <div className="stags"><span>{count} productos</span>{s.instagram && <span>{s.instagram}</span>}</div>
                  <div className="store-actions">
                    <a className="primary" href={`https://wa.me/${s.whatsapp}`} target="_blank">WhatsApp</a>
                    <Link href={`/tiendas/${s.slug}`}>Ver catálogo</Link>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>
      <SiteFooter />
    </>
  );
}
