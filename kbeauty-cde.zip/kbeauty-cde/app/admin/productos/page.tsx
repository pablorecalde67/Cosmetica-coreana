import Link from "next/link";
import { createClient } from "@/lib/supabase/server";
import { deleteProduct } from "@/lib/actions";

export default async function AdminProductsPage() {
  const supabase = createClient();
  const { data: products } = await supabase
    .from("products")
    .select("*, brand:brands(name), category:categories(name)")
    .order("created_at", { ascending: false });

  return (
    <div>
      <div className="section-head" style={{ marginBottom: 20 }}>
        <h2 style={{ fontSize: "1.5rem" }}>Productos</h2>
        <Link href="/admin/productos/nuevo" className="btn">+ Nuevo producto</Link>
      </div>
      <table className="admin-table">
        <thead>
          <tr><th>Nombre</th><th>Marca</th><th>Categoría</th><th>Destacado</th><th></th></tr>
        </thead>
        <tbody>
          {(products ?? []).map((p: any) => (
            <tr key={p.id}>
              <td>{p.name}</td>
              <td>{p.brand?.name ?? "—"}</td>
              <td>{p.category?.name ?? "—"}</td>
              <td>{p.is_featured ? "Sí" : "No"}</td>
              <td style={{ display: "flex", gap: 10 }}>
                <Link href={`/admin/productos/${p.id}`}>Editar</Link>
                <form action={deleteProduct}>
                  <input type="hidden" name="id" value={p.id} />
                  <button className="btn danger" style={{ padding: "4px 10px", fontSize: "0.78rem" }}>Borrar</button>
                </form>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
