import Link from "next/link";
import type { Product } from "@/lib/types";
import { formatPrice, lowestOffer, stockLabel } from "@/lib/format";
import { CategoryIcon, artColor } from "./icons";

export function ProductCard({ product }: { product: Product }) {
  const offer = lowestOffer(product.product_prices);
  const others = (product.product_prices?.length ?? 0) - 1;
  return (
    <Link href={`/producto/${product.slug}`} className="card">
      <div className="card-art" style={{ background: artColor(product.id) }}>
        <CategoryIcon icon={product.category?.icon} />
      </div>
      {offer && (
        <span className={`badge ${offer.stock === "low" ? "low" : offer.stock === "out" ? "out" : ""}`}>
          {stockLabel(offer.stock)}
        </span>
      )}
      <div className="brand">{product.brand?.name}</div>
      <div className="name">{product.name}</div>
      <div className="fn">{product.tagline}</div>
      {others > 0 && <div className="multi-note">+{others} tienda{others > 1 ? "s" : ""} más</div>}
      {offer && (
        <div className="row-bottom">
          <div>
            <div className="price">{formatPrice(offer.price_usd)}</div>
            <div className="store-mini">{offer.store?.name}</div>
          </div>
          <span className="cta">Ver producto</span>
        </div>
      )}
    </Link>
  );
}
