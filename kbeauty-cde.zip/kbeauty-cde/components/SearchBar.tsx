"use client";
import { useRouter } from "next/navigation";
import { useState } from "react";

const EXAMPLES = ["COSRX", "Beauty of Joseon", "Medicube", "Anua", "Torriden", "SKIN1004"];

export function SearchBar() {
  const router = useRouter();
  const [value, setValue] = useState("");

  function go(term: string) {
    if (!term.trim()) return;
    router.push(`/buscar?q=${encodeURIComponent(term)}`);
  }

  return (
    <>
      <form
        className="search-shell"
        onSubmit={(e) => {
          e.preventDefault();
          go(value);
        }}
      >
        <input
          value={value}
          onChange={(e) => setValue(e.target.value)}
          type="text"
          placeholder="¿Qué producto o marca estás buscando?"
          aria-label="Buscar producto o marca"
        />
        <button className="icon" type="submit" aria-label="Buscar">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <circle cx="11" cy="11" r="7" /><line x1="21" y1="21" x2="16.65" y2="16.65" />
          </svg>
        </button>
      </form>
      <div className="search-examples">
        {EXAMPLES.map((e) => (
          <a key={e} href={`/buscar?q=${encodeURIComponent(e)}`}>{e}</a>
        ))}
      </div>
    </>
  );
}
