import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { SiteHeader } from "@/components/SiteHeader";
import { SiteFooter } from "@/components/SiteFooter";
import { ProductCard } from "@/components/ProductCard";
import { getStoreBySlug } from "@/lib/queries";

export async function generateMetadata({ params }: { params: { slug: string } }): Promise<Metadata> {
  const { store } = await getStoreBySlug(params.slug);
  if (!store) return {};
  return { title: `${store.name} — Ciudad del Este` };
}

export default async function StorePage({ params }: { params: { slug: string } }) {
  const { store, products } = await getStoreBySlug(params.slug);
  if (!store) return notFound();
  return (
    <>
      <SiteHeader />
      <section className="block">
        <div className="wrap">
          <div className="section-head">
            <div>
              <span className="eyebrow">Tienda</span>
              <h2>{store.name}</h2>
              <p>{store.address}</p>
            </div>
            {store.whatsapp && <a className="btn" href={`https://wa.me/${store.whatsapp}`} target="_blank">Escribir por WhatsApp</a>}
          </div>
          <div className="grid">
            {products.map((p) => <ProductCard key={p.id} product={p} />)}
            {products.length === 0 && <div className="empty-state">Esta tienda todavía no tiene productos cargados.</div>}
          </div>
        </div>
      </section>
      <SiteFooter />
    </>
  );
}
