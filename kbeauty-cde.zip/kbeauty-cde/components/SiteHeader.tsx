import Link from "next/link";

export function SiteHeader() {
  return (
    <header className="nav">
      <div className="nav-inner">
        <Link href="/" className="logo">CDE<span>Kbeauty</span></Link>
        <nav className="links">
          <Link href="/#categorias">Categorías</Link>
          <Link href="/#precios">Mejores precios</Link>
          <Link href="/marcas">Marcas</Link>
          <Link href="/tiendas/ciudad-del-este">Tiendas</Link>
          <Link href="/rankings">Rankings</Link>
        </nav>
      </div>
    </header>
  );
}
