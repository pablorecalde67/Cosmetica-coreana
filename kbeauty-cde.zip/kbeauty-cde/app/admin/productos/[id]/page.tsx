import { notFound } from "next/navigation";
import { ProductForm } from "@/components/admin/ProductForm";
import { getBrands, getCategories } from "@/lib/queries";
import { createClient } from "@/lib/supabase/server";

export default async function EditProductPage({ params }: { params: { id: string } }) {
  const supabase = createClient();
  const [{ data: product }, brands, categories] = await Promise.all([
    supabase.from("products").select("*").eq("id", params.id).single(),
    getBrands(),
    getCategories(),
  ]);
  if (!product) return notFound();
  return (
    <div>
      <h2 style={{ fontSize: "1.5rem", marginBottom: 20 }}>Editar producto</h2>
      <ProductForm product={product as any} brands={brands} categories={categories} />
    </div>
  );
}
