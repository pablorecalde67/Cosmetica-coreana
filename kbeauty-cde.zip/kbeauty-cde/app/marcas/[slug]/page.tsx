import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { SiteHeader } from "@/components/SiteHeader";
import { SiteFooter } from "@/components/SiteFooter";
import { ProductCard } from "@/components/ProductCard";
import { getProductsByBrandSlug } from "@/lib/queries";

export async function generateMetadata({ params }: { params: { slug: string } }): Promise<Metadata> {
  const { brand } = await getProductsByBrandSlug(params.slug);
  if (!brand) return {};
  return { title: `${brand.name} — Productos disponibles en Ciudad del Este` };
}

export default async function BrandPage({ params }: { params: { slug: string } }) {
  const { brand, products } = await getProductsByBrandSlug(params.slug);
  if (!brand) return notFound();
  return (
    <>
      <SiteHeader />
      <section className="block">
        <div className="wrap">
          <div className="section-head">
            <div>
              <span className="eyebrow">Marca</span>
              <h2>{brand.name}</h2>
              <p>{products.length} producto{products.length !== 1 ? "s" : ""} disponible{products.length !== 1 ? "s" : ""} en Ciudad del Este.</p>
            </div>
          </div>
          <div className="grid">
            {products.map((p) => <ProductCard key={p.id} product={p} />)}
            {products.length === 0 && <div className="empty-state">Todavía no hay productos cargados para esta marca.</div>}
          </div>
        </div>
      </section>
      <SiteFooter />
    </>
  );
}
