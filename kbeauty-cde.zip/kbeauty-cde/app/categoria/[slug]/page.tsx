import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { SiteHeader } from "@/components/SiteHeader";
import { SiteFooter } from "@/components/SiteFooter";
import { ProductCard } from "@/components/ProductCard";
import { getProductsByCategorySlug } from "@/lib/queries";

export async function generateMetadata({ params }: { params: { slug: string } }): Promise<Metadata> {
  const { category } = await getProductsByCategorySlug(params.slug);
  if (!category) return {};
  return { title: `${category.name} — K-Beauty en Ciudad del Este` };
}

export default async function CategoryPage({ params }: { params: { slug: string } }) {
  const { category, products } = await getProductsByCategorySlug(params.slug);
  if (!category) return notFound();
  return (
    <>
      <SiteHeader />
      <section className="block">
        <div className="wrap">
          <div className="section-head">
            <div>
              <span className="eyebrow">Categoría</span>
              <h2>{category.name}</h2>
              <p>{products.length} producto{products.length !== 1 ? "s" : ""} disponible{products.length !== 1 ? "s" : ""} en Ciudad del Este.</p>
            </div>
          </div>
          <div className="grid">
            {products.map((p) => <ProductCard key={p.id} product={p} />)}
            {products.length === 0 && <div className="empty-state">Todavía no hay productos cargados en esta categoría.</div>}
          </div>
        </div>
      </section>
      <SiteFooter />
    </>
  );
}
