# CDE Kbeauty — plataforma de cosmética coreana en Ciudad del Este

Next.js + Supabase. Vitrina pública con SEO por producto/marca/categoría/tienda,
comparador de precios, rankings, y panel de administración protegido.

## 1. Crear el proyecto en Supabase

1. Entrá a https://supabase.com → **New project**.
2. Andá a **SQL Editor** y ejecutá, en este orden:
   - `supabase/schema.sql` (crea las tablas, triggers y seguridad)
   - `supabase/seed.sql` (carga los productos, marcas, tiendas y precios de ejemplo)
3. Andá a **Authentication → Users → Add user** y creá tu usuario administrador
   (email + contraseña). Ese es el login del panel `/admin`.
4. En **Project Settings → API**, copiá:
   - `Project URL`
   - `anon public key`

## 2. Configurar el proyecto localmente

```bash
cp .env.example .env.local
```

Completá `.env.local` con los dos valores de arriba.

```bash
npm install
npm run dev
```

Abrí http://localhost:3000 (sitio público) y http://localhost:3000/admin (panel).

## 3. Publicar en Vercel con tu dominio kbeautycde.com

1. Subí esta carpeta a un repositorio de GitHub.
2. En Vercel → **Add New Project** → importá el repositorio.
3. En **Environment Variables**, agregá `NEXT_PUBLIC_SUPABASE_URL` y
   `NEXT_PUBLIC_SUPABASE_ANON_KEY` (los mismos valores del paso 1).
4. Deploy.
5. En **Project → Settings → Domains**, agregá `kbeautycde.com` y `www.kbeautycde.com`.
   Los registros DNS a cargar en tu proveedor de dominio son los mismos que ya
   tenías preparados:

   | Tipo  | Nombre              | Contenido           |
   |-------|----------------------|---------------------|
   | A     | kbeautycde.com       | 76.76.21.21         |
   | CNAME | www.kbeautycde.com   | cname.vercel-dns.com|

## 4. Cargar contenido real

Todo se administra desde `/admin` (protegido con tu login de Supabase):

- **Productos**: alta/edición/baja, marca, categoría, descripción, ingredientes, destacados.
- **Precios y stock**: precio por tienda + stock (en stock / poco stock / sin stock).
  Cada cambio queda registrado en `price_history` (para alertas de precio a futuro).
- **Marcas** y **Tiendas**: alta y baja rápida.
- **Rankings**: armá listas tipo "Top sérums" agregando productos con una posición.

## 5. Qué quedó armado vs. qué es la base para el futuro

**Ya funciona end-to-end:**
- Buscador (`/buscar?q=`), categorías, comparador de precios por producto,
  "mejores precios", rankings editables, marcas y tiendas con página propia.
- URLs SEO: `/producto/[slug]`, `/marcas/[slug]`, `/categoria/[slug]`, `/tiendas/[slug]`.
- Panel de administración con autenticación (Supabase Auth) para todo el catálogo.
- Historial de precios (tabla `price_history`) para poder construir alertas de
  cambio de precio más adelante.

**Preparado en el esquema pero no construido todavía** (quedó fuera del alcance
de esta primera versión real, tal como estaba marcado como "futuro" en el brief):
- Alertas de cambio de precio / stock por email o WhatsApp.
- Cuentas de usuario final, favoritos, reseñas y puntuaciones.
- Conversión de moneda a Guaraníes/Pesos con tasas reales (hoy los precios
  viven en USD, que es lo que pediste como moneda principal).
- Integración directa con Instagram/Google Maps más allá de los links actuales.
