export type Stock = "in" | "low" | "out";

export interface Brand {
  id: string;
  name: string;
  slug: string;
  description: string | null;
  logo_url: string | null;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  icon: string | null;
  sort_order: number;
}

export interface Store {
  id: string;
  name: string;
  slug: string;
  address: string | null;
  whatsapp: string | null;
  instagram: string | null;
  website: string | null;
  updated_at: string;
}

export interface ProductPrice {
  id: string;
  product_id: string;
  store_id: string;
  price_usd: number;
  stock: Stock;
  updated_at: string;
  store?: Store;
}

export interface Product {
  id: string;
  name: string;
  slug: string;
  brand_id: string | null;
  category_id: string | null;
  tagline: string | null;
  description: string | null;
  benefits: string | null;
  skin_type: string | null;
  key_ingredients: string | null;
  how_to_use: string | null;
  image_url: string | null;
  is_featured: boolean;
  is_new: boolean;
  popularity: number;
  brand?: Brand;
  category?: Category;
  product_prices?: ProductPrice[];
}

export interface Ranking {
  id: string;
  slug: string;
  label: string;
  sort_order: number;
}
