"use client";
import { upsertProduct } from "@/lib/actions";
import type { Brand, Category, Product } from "@/lib/types";

export function ProductForm({
  product,
  brands,
  categories,
}: {
  product?: Product;
  brands: Brand[];
  categories: Category[];
}) {
  return (
    <form action={upsertProduct}>
      {product && <input type="hidden" name="id" value={product.id} />}

      <div className="form-row">
        <div className="form-field">
          <label>Nombre del producto</label>
          <input name="name" defaultValue={product?.name} required />
        </div>
        <div className="form-field">
          <label>Slug (URL) — dejar vacío para generarlo del nombre</label>
          <input name="slug" defaultValue={product?.slug} />
        </div>
      </div>

      <div className="form-row">
        <div className="form-field">
          <label>Marca</label>
          <select name="brand_id" defaultValue={product?.brand_id ?? ""}>
            <option value="">Sin marca</option>
            {brands.map((b) => <option key={b.id} value={b.id}>{b.name}</option>)}
          </select>
        </div>
        <div className="form-field">
          <label>Categoría</label>
          <select name="category_id" defaultValue={product?.category_id ?? ""}>
            <option value="">Sin categoría</option>
            {categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
        </div>
      </div>

      <div className="form-field">
        <label>Función principal (tagline)</label>
        <input name="tagline" defaultValue={product?.tagline ?? ""} />
      </div>

      <div className="form-field">
        <label>Descripción</label>
        <textarea name="description" rows={3} defaultValue={product?.description ?? ""} />
      </div>

      <div className="form-row">
        <div className="form-field">
          <label>Tipo de piel</label>
          <input name="skin_type" defaultValue={product?.skin_type ?? ""} />
        </div>
        <div className="form-field">
          <label>Ingredientes destacados</label>
          <input name="key_ingredients" defaultValue={product?.key_ingredients ?? ""} />
        </div>
      </div>

      <div className="form-field">
        <label>Modo de uso</label>
        <input name="how_to_use" defaultValue={product?.how_to_use ?? ""} />
      </div>

      <div className="form-field">
        <label>URL de foto (opcional)</label>
        <input name="image_url" defaultValue={product?.image_url ?? ""} />
      </div>

      <div className="form-row">
        <div className="form-field">
          <label>Popularidad (0–200, usada para ordenar "más buscados")</label>
          <input name="popularity" type="number" defaultValue={product?.popularity ?? 0} />
        </div>
        <div className="form-field" style={{ flexDirection: "row", alignItems: "center", gap: 20, paddingTop: 22 }}>
          <label style={{ display: "flex", alignItems: "center", gap: 6 }}>
            <input type="checkbox" name="is_featured" defaultChecked={product?.is_featured} /> Destacado
          </label>
          <label style={{ display: "flex", alignItems: "center", gap: 6 }}>
            <input type="checkbox" name="is_new" defaultChecked={product?.is_new} /> Nuevo
          </label>
        </div>
      </div>

      <button className="btn" type="submit" style={{ border: "none" }}>
        {product ? "Guardar cambios" : "Crear producto"}
      </button>
    </form>
  );
}
