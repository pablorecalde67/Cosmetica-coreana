import { createClient } from "@/lib/supabase/server";
import { upsertPrice, deletePrice } from "@/lib/actions";

export default async function AdminPricesPage() {
  const supabase = createClient();
  const [{ data: products }, { data: stores }, { data: prices }] = await Promise.all([
    supabase.from("products").select("id, name").order("name"),
    supabase.from("stores").select("id, name").order("name"),
    supabase.from("product_prices").select("*, product:products(name), store:stores(name)").order("updated_at", { ascending: false }),
  ]);

  return (
    <div>
      <h2 style={{ fontSize: "1.5rem", marginBottom: 20 }}>Precios y stock</h2>
      <p style={{ color: "var(--ink-soft)", fontSize: "0.86rem", marginBottom: 24 }}>
        Cargá o actualizá el precio y el stock de un producto en una tienda. Si ya existe esa combinación, se actualiza (y queda registrada en el historial de precios).
      </p>

      <form action={upsertPrice} style={{ marginBottom: 32, maxWidth: 560 }}>
        <div className="form-row">
          <div className="form-field">
            <label>Producto</label>
            <select name="product_id" required>
              {(products ?? []).map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
            </select>
          </div>
          <div className="form-field">
            <label>Tienda</label>
            <select name="store_id" required>
              {(stores ?? []).map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
            </select>
          </div>
        </div>
        <div className="form-row">
          <div className="form-field">
            <label>Precio (USD)</label>
            <input name="price_usd" type="number" step="0.01" min="0" required />
          </div>
          <div className="form-field">
            <label>Stock</label>
            <select name="stock" defaultValue="in">
              <option value="in">En stock</option>
              <option value="low">Poco stock</option>
              <option value="out">Sin stock</option>
            </select>
          </div>
        </div>
        <button className="btn" style={{ border: "none" }}>Guardar precio</button>
      </form>

      <table className="admin-table">
        <thead><tr><th>Producto</th><th>Tienda</th><th>Precio</th><th>Stock</th><th>Actualizado</th><th></th></tr></thead>
        <tbody>
          {(prices ?? []).map((r: any) => (
            <tr key={r.id}>
              <td>{r.product?.name}</td>
              <td>{r.store?.name}</td>
              <td>US$ {Number(r.price_usd).toFixed(2)}</td>
              <td>{r.stock === "in" ? "En stock" : r.stock === "low" ? "Poco stock" : "Sin stock"}</td>
              <td>{new Date(r.updated_at).toLocaleDateString("es-PY")}</td>
              <td>
                <form action={deletePrice}>
                  <input type="hidden" name="id" value={r.id} />
                  <button className="btn danger" style={{ padding: "4px 10px", fontSize: "0.78rem" }}>Quitar</button>
                </form>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
