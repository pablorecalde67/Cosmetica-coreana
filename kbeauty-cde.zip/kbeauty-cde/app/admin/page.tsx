import { createClient } from "@/lib/supabase/server";

export default async function AdminDashboard() {
  const supabase = createClient();
  const [{ count: products }, { count: brands }, { count: stores }, { data: lowStock }] = await Promise.all([
    supabase.from("products").select("*", { count: "exact", head: true }),
    supabase.from("brands").select("*", { count: "exact", head: true }),
    supabase.from("stores").select("*", { count: "exact", head: true }),
    supabase.from("product_prices").select("id").in("stock", ["low", "out"]),
  ]);

  return (
    <div>
      <h2 style={{ fontSize: "1.5rem", marginBottom: 24 }}>Panel</h2>
      <div className="stat-cards">
        <div className="stat-card"><div className="num">{products ?? 0}</div><div className="lbl">Productos</div></div>
        <div className="stat-card"><div className="num">{brands ?? 0}</div><div className="lbl">Marcas</div></div>
        <div className="stat-card"><div className="num">{stores ?? 0}</div><div className="lbl">Tiendas</div></div>
        <div className="stat-card"><div className="num">{lowStock?.length ?? 0}</div><div className="lbl">Alertas de stock</div></div>
      </div>
      <p style={{ color: "var(--ink-soft)", fontSize: "0.9rem" }}>
        Usá el menú de la izquierda para cargar productos, actualizar precios y stock por tienda,
        y administrar marcas, tiendas y rankings.
      </p>
    </div>
  );
}
