import { createClient } from "@/lib/supabase/server";
import { upsertStore, deleteStore } from "@/lib/actions";

export default async function AdminStoresPage() {
  const supabase = createClient();
  const { data: stores } = await supabase.from("stores").select("*").order("name");

  return (
    <div>
      <h2 style={{ fontSize: "1.5rem", marginBottom: 20 }}>Tiendas</h2>

      <form action={upsertStore} style={{ marginBottom: 32, maxWidth: 560 }}>
        <div className="form-row">
          <div className="form-field"><label>Nombre</label><input name="name" required /></div>
          <div className="form-field"><label>Slug (opcional)</label><input name="slug" /></div>
        </div>
        <div className="form-field"><label>Dirección</label><input name="address" /></div>
        <div className="form-row">
          <div className="form-field"><label>WhatsApp (con código de país, sin +)</label><input name="whatsapp" placeholder="595981000000" /></div>
          <div className="form-field"><label>Instagram</label><input name="instagram" placeholder="@usuario" /></div>
        </div>
        <div className="form-field"><label>Sitio web (opcional)</label><input name="website" /></div>
        <button className="btn" style={{ border: "none" }}>Guardar tienda</button>
      </form>

      <table className="admin-table">
        <thead><tr><th>Nombre</th><th>Dirección</th><th>WhatsApp</th><th></th></tr></thead>
        <tbody>
          {(stores ?? []).map((s) => (
            <tr key={s.id}>
              <td>{s.name}</td>
              <td>{s.address}</td>
              <td>{s.whatsapp}</td>
              <td>
                <form action={deleteStore}>
                  <input type="hidden" name="id" value={s.id} />
                  <button className="btn danger" style={{ padding: "4px 10px", fontSize: "0.78rem" }}>Borrar</button>
                </form>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
