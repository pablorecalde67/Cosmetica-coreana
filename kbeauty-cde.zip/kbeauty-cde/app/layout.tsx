import type { Metadata } from "next";
import { Fraunces, Noto_Sans_KR, Space_Mono } from "next/font/google";
import "./globals.css";

const fraunces = Fraunces({ subsets: ["latin"], variable: "--font-display", weight: ["300", "500", "600"] });
const notoSansKr = Noto_Sans_KR({ subsets: ["latin"], variable: "--font-body", weight: ["300", "400", "500", "700"] });
const spaceMono = Space_Mono({ subsets: ["latin"], variable: "--font-mono", weight: ["400", "700"] });

export const metadata: Metadata = {
  metadataBase: new URL("https://kbeautycde.com"),
  title: {
    default: "CDE Kbeauty — Cosmética coreana en Ciudad del Este",
    template: "%s · CDE Kbeauty",
  },
  description:
    "Buscador y comparador de cosmética coreana en Ciudad del Este. Encontrá productos, precios, stock y tiendas de K-Beauty en un solo lugar.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="es">
      <body
        className={`${fraunces.variable} ${notoSansKr.variable} ${spaceMono.variable}`}
        style={{ fontFamily: "var(--font-body)" }}
      >
        {children}
      </body>
    </html>
  );
}
